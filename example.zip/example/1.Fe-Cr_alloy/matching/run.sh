mkdir build
cd build
../../../../build/scalelat MAP
