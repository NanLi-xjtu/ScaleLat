mkdir build
cd build
cp ../../../../build/scalelat ./
./scalelat MAP
