mkdir build
cd build
../../../../build/scalelat kMC
